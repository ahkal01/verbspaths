package com.digitalml.verbspaths.controller;

import com.digitalml.verbspaths.errormessage.ErrorMessages;
import com.digitalml.verbspaths.service.VerbsPathsService;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class VerbsPathsControllerTests {

    @Autowired
    private MockMvc mvc;

    @Mock
    VerbsPathsService verbsPathsService;

    @Test
    public void BadRequestWhenSwaggerFileParameterIsMissing() throws Exception {
        mvc.perform(get("/verbs-paths"))
                .andExpect(status().isBadRequest());
    }

    @Test
    public void ErrorReadingSwaggerFileWhenIncorrectURLFormat() throws Exception {
        mvc.perform(get("/verbs-paths?swagger=xxx"))
                .andExpect(status().isBadRequest())
                .andExpect(content().string(ErrorMessages.ERROR_READING_SWAGGER_FILE));
    }

    @Test
    public void ErrorReadingSwaggerFileWhenFileDoesNotExist() throws Exception {
        mvc.perform(get("/verbs-paths?swagger=file:xxx"))
                .andExpect(status().isBadRequest())
                .andExpect(content().string(ErrorMessages.ERROR_READING_SWAGGER_FILE));
    }

    @Test
    public void ErrorReadingSwaggerFileWhenUrlDoesNotExist() throws Exception {
        mvc.perform(get("/verbs-paths?swagger=https://xxx"))
                .andExpect(status().isBadRequest())
                .andExpect(content().string(ErrorMessages.ERROR_READING_SWAGGER_FILE));
    }

    @Test
    public void ErrorReadingSwaggerFileWhenBadJson() throws Exception {
        mvc.perform(get("/verbs-paths?swagger=file:testdata/badjson.txt"))
                .andExpect(status().isBadRequest())
                .andExpect(content().string(ErrorMessages.ERROR_READING_SWAGGER_FILE));
    }

    @Test
    public void SampleFile() throws Exception {

        String expectedOutput = "DELETE:\n\n"
                + "\t/user\n\n"
                + "GET:\n\n"
                + "\t/account\n\n"
                + "\t/user\n\n"
                + "POST:\n\n"
                + "\t/account\n\n"
                + "\t/user\n\n";

        mvc.perform(get("/verbs-paths?swagger=file:testdata/sample.json"))
                .andExpect(status().isOk())
                .andExpect(content().string(expectedOutput));
    }

    @Test
    public void PetStore() throws Exception {

        String expectedOutput = "DELETE:\n\n"
                + "\t/pet/{petId}\n\n"
                + "\t/store/order/{orderId}\n\n"
                + "\t/user/{username}\n\n"
                + "GET:\n\n"
                + "\t/pet/findByStatus\n\n"
                + "\t/pet/findByTags\n\n"
                + "\t/pet/{petId}\n\n"
                + "\t/store/inventory\n\n"
                + "\t/store/order/{orderId}\n\n"
                + "\t/user/{username}\n\n"
                + "\t/user/login\n\n"
                + "\t/user/logout\n\n"
                + "POST:\n\n"
                + "\t/pet/{petId}/uploadImage\n\n"
                + "\t/pet\n\n"
                + "\t/pet/{petId}\n\n"
                + "\t/store/order\n\n"
                + "\t/user/createWithList\n\n"
                + "\t/user/createWithArray\n\n"
                + "\t/user\n\n"
                + "PUT:\n\n"
                + "\t/pet\n\n"
                + "\t/user/{username}\n\n";

        mvc.perform(get("/verbs-paths?swagger=https://petstore.swagger.io/v2/swagger.json"))
                .andExpect(status().isOk())
                .andExpect(content().string(expectedOutput));
    }
}
