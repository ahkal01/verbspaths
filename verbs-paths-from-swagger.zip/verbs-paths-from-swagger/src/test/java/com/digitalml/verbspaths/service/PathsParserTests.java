package com.digitalml.verbspaths.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class PathsParserTests {

    @Autowired
    private PathsParser pathsParser;

    @Test
    public void EmptyMapWhenNoPaths() throws JsonMappingException, JsonProcessingException {
        String testJson = "{ \"paths\" : \"\" }";
        Map<String, List<String>> verbsToPath = pathsParser.parseNode(getPathsNode(testJson));
        assertTrue(verbsToPath.isEmpty());
    }

    @Test
    public void EmptyMapWhenNoVerbs() throws JsonMappingException, JsonProcessingException {
        String testJson = "{ \"paths\" : { \"/account\": \"\"} }";
        Map<String, List<String>> verbsToPath = pathsParser.parseNode(getPathsNode(testJson));
        assertTrue(verbsToPath.isEmpty());
    }

    @Test
    public void OneVerbWithOnePath() throws JsonMappingException, JsonProcessingException {
        String testJson = "{ \"paths\" : { \"/account\": { \"get\": { \"operationId\": \"getAccount\" } } } }";
        SortedMap<String, List<String>> verbsToPath = pathsParser.parseNode(getPathsNode(testJson));
        assertAll(
            () -> assertEquals(Set.of("GET"), verbsToPath.keySet()),
            () -> assertLinesMatch(List.of("/account"), verbsToPath.get("GET"))
        );
    }

    @Test
    public void TwoVerbsWithOnePathEach() throws JsonMappingException, JsonProcessingException {
        String testJson = "{ \"paths\" : { \"/account\": { "
                                + "\"get\": { \"operationId\": \"getAccount\" }, "
                                + "\"put\": { \"operationId\": \"putAccount\" } "
                                + "} } }";
        SortedMap<String, List<String>> verbsToPath = pathsParser.parseNode(getPathsNode(testJson));
        assertAll(
                () -> assertEquals(Set.of("GET", "PUT"), verbsToPath.keySet()),
                () -> assertEquals("GET", verbsToPath.firstKey()),
                () -> assertLinesMatch(List.of("/account"), verbsToPath.get("GET")),
                () -> assertLinesMatch(List.of("/account"), verbsToPath.get("PUT"))
        );
    }

    @Test
    public void OneVerbWithTwoPaths() throws JsonMappingException, JsonProcessingException {
        String testJson = "{ \"paths\" : { \"/account\": { \"get\": { \"operationId\": \"getAccount\" } } , "
                                        + "\"/user\": { \"get\": { \"operationId\": \"getUser\" } } } }";
        SortedMap<String, List<String>> verbsToPath = pathsParser.parseNode(getPathsNode(testJson));
        assertAll(
                () -> assertEquals(Set.of("GET"), verbsToPath.keySet()),
                () -> assertLinesMatch(List.of("/account", "/user"), verbsToPath.get("GET"))
        );
    }

    private JsonNode getPathsNode(String json) throws JsonMappingException, JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode rootNode = objectMapper.readValue(json, JsonNode.class);
        return rootNode.get("paths");
    }
}
