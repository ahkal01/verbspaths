package com.digitalml.verbspaths;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VerbsPathsApplicationTests {

	@Test
	void contextLoads() {
	}

}
