package com.digitalml.verbspaths.service;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;
import java.util.SortedMap;
import java.util.TreeMap;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest
public class VerbPathsPrinterTests {

    @Autowired
    private VerbsPathsPrinter verbsPathsPrinter;

    @Test
    public void EmptyOutputWhenEmptyMap() {
        assertEquals("", verbsPathsPrinter.print(new TreeMap<String, List<String>>()));
    }

    @Test
    public void OneVerbWithOnePath() {

        SortedMap<String, List<String>> mapWithOneVerbOnePath = new TreeMap<String, List<String>>();
        mapWithOneVerbOnePath.put("GET", List.of("/account"));

        String expectedOutput = "GET:\n\n"
                + "\t/account\n\n";

        assertEquals(expectedOutput, verbsPathsPrinter.print(mapWithOneVerbOnePath));
    }

    @Test
    public void OneVerbWithTwoPaths() {

        SortedMap<String, List<String>> mapWithOneVerbOnePath = new TreeMap<String, List<String>>();
        mapWithOneVerbOnePath.put("GET", List.of("/account", "/user"));

        String expectedOutput = "GET:\n\n"
                + "\t/account\n\n"
                + "\t/user\n\n";

        assertEquals(expectedOutput, verbsPathsPrinter.print(mapWithOneVerbOnePath));
    }

    @Test
    public void OutputSortedByVerb() {

        SortedMap<String, List<String>> mapWithTwoVerbsOnePath = new TreeMap<String, List<String>>();
        mapWithTwoVerbsOnePath.put("GET", List.of("/account"));
        mapWithTwoVerbsOnePath.put("DELETE", List.of("/account"));

        String expectedOutput = "DELETE:\n\n"
                + "\t/account\n\n"
                + "GET:\n\n"
                + "\t/account\n\n";

        assertEquals(expectedOutput, verbsPathsPrinter.print(mapWithTwoVerbsOnePath));
    }
}
