package com.digitalml.verbspaths.service;

import com.fasterxml.jackson.databind.JsonNode;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.util.List;
import java.util.SortedMap;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;

@SpringBootTest
public class VerbPathsServiceTests {

    @Autowired
    private VerbsPathsService verbsPathsService;

    @MockBean
    private SwaggerFileReader swaggerFileReader;

    @MockBean
    private PathsParser pathsParser;

    @MockBean
    private VerbsPathsPrinter verbsPathsPrinter;

    @Mock
    private SortedMap<String, List<String>> mockVerbsToPaths;

    @Test
    public void FileIsReadPathsAreParsedMapIsPrinted() throws Exception {

        final String testPath = "https://test/test.json";
        JsonNode mockPathsNode = mock(JsonNode.class);

        String output = "GET:\n\n"
                + "\t/account\n\n"
                + "\t/user\n\n";

        Mockito.when(swaggerFileReader.readFile(testPath)).thenReturn(mockPathsNode);
        Mockito.when(pathsParser.parseNode(mockPathsNode)).thenReturn(mockVerbsToPaths);
        Mockito.when(verbsPathsPrinter.print(mockVerbsToPaths)).thenReturn(output);

        assertEquals(output, verbsPathsService.getVerbsAndPathsFromSwagger(testPath));

        Mockito.verify(swaggerFileReader, times(1)).readFile(testPath);
        Mockito.verify(pathsParser, times(1)).parseNode(mockPathsNode);
        Mockito.verify(verbsPathsPrinter, times(1)).print(mockVerbsToPaths);
    }
}
