package com.digitalml.verbspaths.controller;

import com.digitalml.verbspaths.exception.FileReadException;
import com.digitalml.verbspaths.exception.PathsNodeException;
import com.digitalml.verbspaths.service.VerbsPathsService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class VerbsPathsController {

    private VerbsPathsService verbsPathsService;

    public VerbsPathsController(VerbsPathsService verbsPathsService) {
        this.verbsPathsService = verbsPathsService;
    }

    @Operation(summary = "Extracts Verbs and Paths from a Swagger file",
            description = "Parses a Swagger file and outputs the verbs with the associated paths.")
    @GetMapping("/verbs-paths")
    public ResponseEntity<String> getVerbsAndPathsFromSwagger(
            @Parameter(description = "URL of Swagger file e.g. https://petstore.swagger.io/v2/swagger.json, file:c:/testdata/sample.json")
            @RequestParam("swagger") String swaggerFilePath) {

        try {
            String verbsAndPaths = verbsPathsService.getVerbsAndPathsFromSwagger(swaggerFilePath);
            return new ResponseEntity<>(verbsAndPaths, HttpStatus.OK);
        }
        catch (FileReadException | PathsNodeException ex) {
            return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
}
