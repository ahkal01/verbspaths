package com.digitalml.verbspaths.errormessage;

public class ErrorMessages {

    public static final String ERROR_READING_SWAGGER_FILE = "Error reading Swagger file";
    public static final String MISSING_PATHS_IN_SWAGGER_FILE = "Missing paths in Swagger file";
}
