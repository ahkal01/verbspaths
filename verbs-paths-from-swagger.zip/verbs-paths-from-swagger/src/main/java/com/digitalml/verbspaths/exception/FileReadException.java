package com.digitalml.verbspaths.exception;

public class FileReadException extends Exception{
    public FileReadException(String errorMessage) {
        super(errorMessage);
    }
}
