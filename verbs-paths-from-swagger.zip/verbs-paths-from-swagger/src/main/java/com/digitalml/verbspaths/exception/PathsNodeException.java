package com.digitalml.verbspaths.exception;

public class PathsNodeException extends Exception{
    public PathsNodeException(String errorMessage) {
        super(errorMessage);
    }
}
