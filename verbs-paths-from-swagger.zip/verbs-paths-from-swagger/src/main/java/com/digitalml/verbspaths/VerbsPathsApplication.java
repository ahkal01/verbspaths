package com.digitalml.verbspaths;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VerbsPathsApplication {

	public static void main(String[] args) {

		SpringApplication.run(VerbsPathsApplication.class, args);
	}

}
