package com.digitalml.verbspaths.service;

import org.springframework.stereotype.Component;

import java.util.List;
import java.util.SortedMap;

/**
 * Service to produce the output string of verbs with their associated paths
 *
 */
@Component
public class VerbsPathsPrinter {
    private static final String EOL = "\n\n";
    private static final String INDENT = "\t";

    /**
     * <p>Produces the output string of verbs with their associated paths
     * </p>
     * @param verbsToPaths verbs mapped to the list of the associated paths
     * @return the output string of verbs with their associated paths
     */
    public String print(SortedMap<String, List<String>> verbsToPaths) {

        StringBuilder output = new StringBuilder();
        verbsToPaths.forEach((verb, paths) -> output.append(print(verb, paths)));
        return output.toString();
    }

    private String print(String verb, List<String> paths) {
        StringBuilder output = new StringBuilder(verb + ":" + EOL);
        paths.forEach((path) -> output.append(INDENT + path + EOL));
        return output.toString();
    }
}
