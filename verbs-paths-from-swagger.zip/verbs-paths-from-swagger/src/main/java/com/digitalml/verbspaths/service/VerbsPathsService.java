package com.digitalml.verbspaths.service;

import com.digitalml.verbspaths.exception.FileReadException;
import com.digitalml.verbspaths.exception.PathsNodeException;
import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.SortedMap;

/**
 * Service to get verbs and paths from a Swagger file
 *
 */
@Service
public class VerbsPathsService {

    private SwaggerFileReader swaggerFileReader;
    private PathsParser pathsParser;
    private VerbsPathsPrinter verbsPathsPrinter;

    public VerbsPathsService(SwaggerFileReader swaggerFileReader, PathsParser pathsParser, VerbsPathsPrinter verbsPathsPrinter) {
        this.swaggerFileReader = swaggerFileReader;
        this.pathsParser = pathsParser;
        this.verbsPathsPrinter = verbsPathsPrinter;
    }

    /**
     * <p>Get verbs and the associated paths from a Swagger file
     * </p>
     * @param swaggerFilePath URL of Swagger file e.g. https://petstore.swagger.io/v2/swagger.json, file:c:/testdata/sample.json
     * @return the output string of verbs with their associated paths
     */
    public String getVerbsAndPathsFromSwagger(String swaggerFilePath) throws FileReadException, PathsNodeException {

        JsonNode pathsNode = swaggerFileReader.readFile(swaggerFilePath);
        SortedMap<String, List<String>> verbsToPaths = pathsParser.parseNode(pathsNode);
        String output = verbsPathsPrinter.print(verbsToPaths);

        return output;
    }
}
