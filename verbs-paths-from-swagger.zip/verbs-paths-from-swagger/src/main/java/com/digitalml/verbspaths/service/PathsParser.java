package com.digitalml.verbspaths.service;

import com.fasterxml.jackson.databind.JsonNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * Service to parse the paths node from a Swagger file
 *
 */
@Component
public class PathsParser {

    private static final Logger logger = LoggerFactory.getLogger(PathsParser.class);

    /**
     * <p>Parses the paths node from a Swagger file
     * </p>
     * @param pathsNode the JSON paths node
     * @return verbs mapped to the list of the associated paths.  The verbs are sorted in natural order.
     */
    public SortedMap<String, List<String>> parseNode(JsonNode pathsNode) {

        SortedMap<String, List<String>> verbsToPaths = new TreeMap<> ();

        Iterator<String> pathIterator = pathsNode.fieldNames();
        while (pathIterator.hasNext()) {

            String path = pathIterator.next();

            JsonNode pathNode = pathsNode.get(path);
            pathNode.fieldNames().forEachRemaining(verb -> addPathToVerb(verbsToPaths, path, verb));
        }

        return verbsToPaths;
    }

    private void addPathToVerb(SortedMap<String, List<String>> verbsToPaths, String path, String verb) {

        String verbUpperCase = verb.toUpperCase();

        List<String> pathsForVerb = verbsToPaths.get(verbUpperCase);
        if (pathsForVerb == null) {
            pathsForVerb = new ArrayList<> ();
        }
        pathsForVerb.add(path);
        verbsToPaths.put(verbUpperCase, pathsForVerb);

        logger.info("Added path {} to verb {}", path, verbUpperCase);
    }
}
