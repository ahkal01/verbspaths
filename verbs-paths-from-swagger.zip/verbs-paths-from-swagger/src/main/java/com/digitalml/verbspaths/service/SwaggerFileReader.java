package com.digitalml.verbspaths.service;

import com.digitalml.verbspaths.errormessage.ErrorMessages;
import com.digitalml.verbspaths.exception.PathsNodeException;
import com.digitalml.verbspaths.exception.FileReadException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.net.URL;

/**
 * Service to read a Swagger file
 *
 */
@Component
public class SwaggerFileReader {

    private static final String PATHS_NODE_NAME = "paths";
    private static final Logger logger = LoggerFactory.getLogger(SwaggerFileReader.class);

    /**
     * <p>Read a Swagger file
     * </p>
     * @param filePath URL of Swagger file e.g. https://petstore.swagger.io/v2/swagger.json, file:c:/testdata/sample.json
     * @return the JSON node for paths in the Swagger file
     */
    public JsonNode readFile(String filePath) throws FileReadException, PathsNodeException {

        ObjectMapper objectMapper = new ObjectMapper();

        try {
            JsonNode swaggerRootNode = objectMapper.readValue(new URL(filePath), JsonNode.class);
            JsonNode pathsNode = swaggerRootNode.get(PATHS_NODE_NAME);
            validatePaths(filePath, pathsNode);
            return pathsNode;
        }
        catch (IOException ex)
        {
            logger.error("Error reading {}, {}", filePath, ex.getMessage());
            throw new FileReadException(ErrorMessages.ERROR_READING_SWAGGER_FILE);
        }
    }

    private void validatePaths(String filePath, JsonNode pathsNode) throws PathsNodeException {
        if (pathsNode == null || pathsNode.isEmpty() || pathsNode.size() == 0) {
            logger.error("Paths node is missing in {}", filePath);
            throw new PathsNodeException(ErrorMessages.MISSING_PATHS_IN_SWAGGER_FILE);
        }
    }
}
